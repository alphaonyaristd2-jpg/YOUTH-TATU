
Tatu Youth Raise — 9-page neon-gradient site with per-page video background placeholders
-------------------------------------------------------------------------------------
Files:
- index.html, about.html, programs.html, events.html, gallery.html, blog.html, volunteer.html, contact.html, donate.html
- privacy.html, terms.html
- styles.css, script.js
- assets/hero-poster-1.jpg .. hero-poster-9.jpg (poster placeholders)
- assets/hero-1.mp4 .. hero-9.mp4 (NOT included; place your video files here)
- assets/gallery-1.jpg .. gallery-6.jpg (placeholders)

To enable per-page videos:
- Add your short muted looped videos named: assets/hero-1.mp4 ... assets/hero-9.mp4.
- Use mp4 or webm for best browser support. Keep videos short and optimized (~1-5 MB each ideally).

Open index.html in a browser to preview. Replace content and assets as needed.
