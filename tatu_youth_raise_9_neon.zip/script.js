
document.addEventListener('DOMContentLoaded', function(){
  var nav = document.getElementById('nav');
  var btn = document.getElementById('nav-toggle');
  if(btn){btn.addEventListener('click', function(){nav.classList.toggle('show');this.setAttribute('aria-expanded', String(nav.classList.contains('show')));});}
  var forms = document.querySelectorAll('form');
  forms.forEach(function(form){form.addEventListener('submit', function(e){e.preventDefault();var m=form.querySelector('.form-msg');if(!m){m=document.createElement('p');m.className='form-msg';form.appendChild(m);}m.textContent='Thanks! Message received (demo).';m.style.color='';form.reset();});});
  // fade-up on scroll
  var obs = new IntersectionObserver(function(entries){entries.forEach(function(en){if(en.isIntersecting){en.target.classList.add('fade-up');obs.unobserve(en.target);}});},{threshold:0.12});
  document.querySelectorAll('.card, .hero-text, .gallery-grid img').forEach(function(el){obs.observe(el);});
  // gallery lightbox
  document.querySelectorAll('.gallery-grid img').forEach(function(img){
    img.style.cursor='pointer';
    img.addEventListener('click', function(){
      var modal=document.createElement('div');modal.style.position='fixed';modal.style.inset=0;modal.style.background='rgba(0,0,0,0.85)';modal.style.display='flex';modal.style.alignItems='center';modal.style.justifyContent='center';modal.style.zIndex=9999;
      var clone=img.cloneNode();clone.style.maxWidth='90%';clone.style.maxHeight='90%';clone.style.borderRadius='12px';modal.appendChild(clone);modal.addEventListener('click', function(){modal.remove();});document.body.appendChild(modal);
    });
  });
});
